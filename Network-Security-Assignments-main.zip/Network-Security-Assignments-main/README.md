## Process Followed in each Assignment.
<br/>

### Encryption & Decryption using Poly-alphabetic Substitution
![Process](https://user-images.githubusercontent.com/43794593/154127846-df50c6ac-02f5-4db4-a99d-177391414857.png)

### AES(Advanced Encryption Standard)
![Process1](https://user-images.githubusercontent.com/43794593/154126947-714b4580-506b-4ac9-ae31-a34dace11aa1.png)

![Process2](https://user-images.githubusercontent.com/43794593/154127007-90f6a035-27c7-4a01-8c77-4dca647be2da.png)

![Process3](https://user-images.githubusercontent.com/43794593/154127058-fd566c8c-a5d5-4f0c-bf63-c8f24d99ee2c.png)

### Digitally Signed Degree Certificates
![Process](https://user-images.githubusercontent.com/43794593/154127158-0b04bc58-f13a-48e3-8257-83b4a243aa84.png)

### Public Key Distribution Authority (PKDA)
![Process](https://user-images.githubusercontent.com/43794593/154127199-21f10fe0-aa8d-4497-960d-0657e0beeff5.png)
